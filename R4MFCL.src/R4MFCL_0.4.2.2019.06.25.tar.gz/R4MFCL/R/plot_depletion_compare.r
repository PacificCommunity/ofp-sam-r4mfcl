#' Updated plots of depletion that can either plot the fully dynamic depletion or the moving reference point
#'
#' @param legpos
#' @param repfiles
#' @param modlab
#' @param type
#' @param cls
#'
#' @export

plot_depletion_compare <- function(legpos="topright",
                                   repfiles=list(read.rep("C:/condor_work/runs/run10/plot-11.par.rep"),
                                                 read.rep("C:/condor_work/runs/run4/plot-11.par.rep"),
                                                 read.rep("C:/condor_work/runs/run7/plot-11.par.rep")),
                                   modlab = NULL, type="SSB",cls=NULL,Ref="current")
{
# SJH 9/7/2015 - hack from biomass compare
    if(is.null(modlab)) {modlab <- paste("model",seq(1,length(repfiles))) }

    ## par(mfrow=c(1,1),oma=c(1,2,1,1))

    maxy <- c()
    recr <- list()

    for(i in 1:length(repfiles))
    {

      nyr <- repfiles[[i]]$nTimes
    #first year
      year1 <- repfiles[[i]]$Year1
    #number of time steps per year
      tsteps <- repfiles[[i]]$nRecs.yr
        year <- seq(year1,length=nyr,by=1/tsteps)
        xlimits=c(year1,year[length(year)])
      nregion <- repfiles[[i]]$nReg

    if(type=="SSB")
    {
      if(!nregion == 1)
      {
          B <- apply(repfiles[[i]]$AdultBiomass,1,sum)
          Bnof <- apply(repfiles[[i]]$AdultBiomass.nofish,1,sum)
      } else {
          B <- repfiles[[i]]$AdultBiomass
          Bnof <- repfiles[[i]]$AdultBiomass.nofish
      }

        if(Ref=="latest"){
            textlab <- expression("Estimate of depletion "*phantom(10)*"SB "["latest"]*" / "*bar("SB "["F=0"]))
        } else if (Ref=="recent"){
            textlab <- expression("Estimate of depletion "*phantom(10)*"SB "["recent"]*" / "*bar("SB "["F=0"]))
        } else{
            textlab <- expression("Estimate of depletion "*phantom(10)*"SB "["t"]*" / SB "["t, F=0"])
        }
        ## if(Ref=="latest"){
        ##     textlab <- expression("Estimate of depletion "*phantom(100)*frac("SB "["latest"], dot("SB "["F=0"])))
        ## } else if (Ref=="recent"){
        ##     textlab <- expression("Estimate of depletion "*phantom(100)*frac("SB "["recent"], dot("SB "["F=0"])))
        ## } else{
        ##     textlab <- expression("Estimate of depletion "*phantom(100)*frac("SB"["t"],"SB "["t, F=0"]))
        ## }
    }
    else
    {
      if(!nregion == 1)
      {
        B <- apply(repfiles[[i]]$TotBiomass,1,sum)
        Bnof <- apply(repfiles[[i]]$TotalBiomass.nofish,1,sum)
      } else {
        B <- repfiles[[i]]$TotBiomass
        Bnof <- repfiles[[i]]$TotalBiomass.nofish
      }
      textlab <- "Proportion of total biomass"
    }

        if (Ref=="latest") {
            Byr=aggregate(B,list(trunc(year)),mean)
            BnoFyr=aggregate(Bnof,list(trunc(year)),mean)$x
            BnoFyr=stats::filter(BnoFyr,rep(1,10),sides=1)/10
            BnoFyr=c(NA,BnoFyr[1:(length(BnoFyr)-1)])
            recr[[i]] <- Byr
            recr[[i]][,2] <- Byr$x/BnoFyr
        } else if(Ref=="recent"){
            Byr=aggregate(B,list(trunc(year)),mean)
            Byr$x=stats::filter(Byr$x,rep(1,4),sides=1)/4
            BnoFyr=aggregate(Bnof,list(trunc(year)),mean)$x
            BnoFyr=stats::filter(BnoFyr,rep(1,10),sides=1)/10
            BnoFyr=c(NA,BnoFyr[1:(length(BnoFyr)-1)])
            recr[[i]] <- Byr
            recr[[i]][,2] <- Byr$x/BnoFyr
        } else {
            dplt <- B/Bnof
            recr[[i]] <- cbind(year,dplt)
        }
    }

    ymax=max(c(1,sapply(1:length(recr),function(x) max(recr[[x]][,2],na.rm=TRUE))))
    par(las=0)
    plot(recr[[1]][,1],recr[[1]][,2], xlim = xlimits, ylim=c(0,ymax), ylab="", xlab="", type="n",las=1)

    for(i in 2:length(recr)){
      if(is.null(cls)) mycol <- i else mycol <- cls[i]

	    lines(recr[[i]][,1],recr[[i]][,2], lwd=2, col=mycol)
    }
# Plot reference case last
    if(is.null(cls)) mycol <- 1 else mycol <- cls[1]
	  lines(recr[[1]][,1],recr[[1]][,2], lwd=2, col=mycol)

    if(is.null(cls)) mycol <- c(1:length(recr)) else mycol <- cls

    legend(legpos, lwd=2, col=mycol, lty=1, legend=modlab,bty="n")
    mtext(side=2, text=textlab, line=3.5)
}


