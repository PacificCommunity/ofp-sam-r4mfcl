ppath <-
function(p1,p2) paste(p1,p2,sep="/")

