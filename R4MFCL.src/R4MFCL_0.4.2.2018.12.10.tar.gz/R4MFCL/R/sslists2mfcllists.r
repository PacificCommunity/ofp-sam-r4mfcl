
sslists2mfcllists<-function(datlist,ctllist,version,frqfile="mfcl.frq"){

  ## utility function to read and store data (to be written later)

   # Function to add vector to datalist

  add_vec<-function(datalist,length,name,verbose=TRUE){
    i<-datalist$'.i'
    dat<-datalist$'.dat'
    datalist$temp<-dat[i+1:length-1]
    if(verbose){
      cat(name,",i=",datalist$'.i'," : ")
    }
    datalist$'.i'<-i+length
    if(!is.na(name))names(datalist)[names(datalist)=="temp"]<-name
    if(verbose){
      print(datalist[[which(names(datalist)==name)]])
    }
#    cat("L51\n");browser()
    return(datalist)
  }


  add_df<-
  	function(datalist,name,nrow,ncol,col.names=NULL,
  	verbose=TRUE,comments=NULL,headerComments=NULL){
    k<-nrow*ncol
    i<-datalist$'.i'
    dat<-datalist$'.dat'
    df0<-as.data.frame(matrix(dat[i+1:k-1],nrow=nrow,ncol=ncol,byrow=TRUE))
    if(!is.null(col.names))colnames(df0)<-col.names
    if(is.null(comments)){
      rownames(df0)<-paste0(paste0("#_",name,collapse=""),1:nrow)
    }else{
      rownames(df0)<-comments
    }
    if(verbose){
      cat(name,",i=",datalist$'.i',"\n")
    }
    i <- i+k
    datalist$temp<-df0
    datalist$'.i'<-i
    if(!is.na(name))names(datalist)[names(datalist)=="temp"]<-name
    if(verbose){
      print(datalist[[which(names(datalist)==name)]])
    }
    return(datalist)
  }



  ## function to add an element to datalist
  add_elem<-function(datalist=NA,name,verbose=TRUE){
    i<-datalist$'.i'
    dat<-datalist$'.dat'
    datalist$temp<-dat[i]
 #   cat("L86\n");browser()
    if(verbose)cat(name,",i=",datalist$'.i'," ;")
    datalist$'.i'<-i+1
    if(!is.na(name))names(datalist)[names(datalist)=="temp"]<-name
    if(verbose)cat(datalist[[which(names(datalist)==name)]],"\n")
    return(datalist)
  }

  ## function to add list  to datalist
  add_list<-function(datalist=NA,name,length,length_each,verbose=TRUE){
    i<-datalist$'.i'
    dat<-datalist$'.dat'
    if(verbose)cat(name,",i=",datalist$'.i',"\n")
     datalist$temp<-list()
    for(j in 1:length){
      datalist$temp[[j]]<-dat[i+1:length_each[j]-1]; i <- i+length_each[j]
    }
    datalist$'.i'<-i
    if(!is.null(name))names(datalist)[names(datalist)=="temp"]<-name
  #  if(verbose)cat(name,",i=",datalist$'.i',"\n")
    return(datalist)
  }

  ## function to add frq data to list and then to datalist
  add_list_frqdata<-function(datalist=NA,name,length,
    frqVersion,
    verbose=TRUE,
    NumSpecies=0,
    NLbin,
    NWbin,
    convert4to6=FALSE){
    i<-datalist$'.i'
    dat<-datalist$'.dat'
    datalist$temp<-list()
    if(frqVersion==8){
      Nheader<- 7+NumSpecies*2
    }else if(frqVersion==6){
      Nheader<- 7
    }else if(frqVersion==9){
      Nheader<- 7+NumSpecies*4
    }else{
      Nheader<-6
    }
    frqHeader<-list()
    frqCE<-list()
    frqData<-list()
    if(NumSpecies>1){
      spDat<-list()
      spIndex<-list()
      spFlag<-list()
      if(frqVersion==9){
        spLenFlag<-list()
        spWtFlag<-list()
      }

    }
	}


  # set initial position in the vector of numeric values
  i <- 1
  # create empty list to store quantities
  frqlist <- list()
  frqlist$'.i'<-i
  ################
  setterDatlistGenerater<-function(sslist){
    setterDatlist<-function(name,val){
      sslist[[name]]<<-val
      if(verbose){
        print(name)
        print(sslist[[name]])
      }
      return(invisible(sslist))
    }
    return(setterDatlist)
  }

  setterFrqlist<-setterDatlistGenerater(frqlist)

  ################################
  # frqlist$'.dat'<-allnums
  frqlist$sourcefile<-frqfile

  if(verbose)cat("Starting to interpret and store data in frq file\n")
  frqlist<-setterFrqlist("Nregion",datlist$N_areas)
  frqlist<-setterFrqlist("Nfish",datlist$Nfleet)
  frqlist<-setterFrqlist("GenericDifusion",1)
  frqlist<-setterFrqlist("NtagGrp",0)
  frqlist<-setterFrqlist("styr",datlist$styr)

  frqlist<-setterFrqlist("NtagGrp",0)
  frqlist<-setterFrqlist("NumSpecies",1)   ## Number of species/sex (not used if frqVersion<8)

  frqlist<-setterFrqlist("LenOrAge",0) ## flag to indicate whether the frequency data are length (0) or age (1) data
  frqlist<-add_elem(frqlist,"Nrec") ## number of recruitments per year assumed in the model
  frqlist<-add_elem(frqlist,"RecMonth")
  frqlist<-add_elem(frqlist,"frqVersion")
  frqVersion<-6 #   frqlist$frqVersion
  if(frqlist$NumSpecies==0 )frqlist$NumSpecies<-1
  NumSpecies<-frqlist$NumSpecies
  # .frq file version number – indicates for which version of MULTIFAN-CL the data
  #  files were constructed (intended for backward compatibility, but in practice causes
  #  MULTIFAN-CL to announce “Die yuppie scum” and quit when it encounters a .frq
  #  file that is incompatible with the MULTIFAN-CL code version)
  #  if(frqlist$frqVersion %in% c(8,9)){
  #    multisexsp<-TRUE
  #  }else{
  #    multisexsp<-FALSE
  #  }
  multisexsp<-FALSE
  #  cat("L252\n");browser()
  #if(frqVersion %in% c(8,9) & NumSpecies>1){
  #  frqlist<-add_vec(frqlist,length=NumSpecies,"NtagGrpBySp")
  #  if(sum(frqlist$NtagGrpBySp)!=frqlist$NtagGrp)
  #    stop("sum(frqlist$NtagGrpBySp)!=frqlist$NtagGrp")
  #  frqlist<-add_df(frqlist,"spRegion",nrow=NumSpecies,ncol=frqlist$Nregions,col.names=paste0("Region",1:frqlist$Nregion))
  #}
  frqlist<-setterFrqlist("regionSize",rep(1,times=frqlist$Nregions))
  frqlist<-setterFrqlist("fishRegion",rep(1,times=frqlist$Nfish))
  #if(frqlist$Nregions>1){
  #  frqlist<-add_df(frqlist,name="IncidentMat",nrow=NumSpecies,ncol=frqlist$Nregions*(frqlist$Nregions-1)/2)
  #}
  
  #  cat("L264\n");browser()
  #frqlist<-add_df(frqlist,"frqDatFlags",nrow=5,ncol=frqlist$Nfish,col.names=paste0("FL",1:frqlist$Nfish),
  #  headerComments="# Data flags (for records 1, 0=catch in number; 1=catch in weight)")
  
  frqDatFlags<-as.data.frame(matrix(data=rep(0,5*1:frqlist$Nfish),nrow=5,ncol=frqlist$Nfish),col.names=paste0("FL",1:frqlist$Nfish))
  frqDatFlags[1,]<-datlist$units_of_catch-1
  
  frqlist<-setterFrqlist("frqDatFlags",frqDatFlags)
  
  Season_Region_Flags<-as.data.frame(matrix(data=rep(1,frqlist$Nrec*frqlist$Nregions),nrow=4),col.names=paste0("Reg",1:frqlist$Nregions))
  frqlist<-setterFrqlist("Season_Region_Flags",Season_Region_Flags)

  frqlist<-setterFrqlist("NmovesPerYr",1) # Number of movement per year

  if(frqlist$NmovesPerYr==1){
    frqlist<-setterFrqlist("WeeksMoves",5) # Weeks in which movement occurs
  }else{
    frqlist<-setterFrqlist("WeeksMoves",c(5,17,29,41)) # Weeks in which movement occurs
  }
  if(datlist$N_sizefreq_methods>0){
    # Currently not all features of generalized size composition data is supported by MFCL
    # Therefore it is needed to stop conversion if any unsupported features are used
    if(any(datlist$units_per_method==1))stop("Generalized size compositions of unit=weght(bio) is not supported")
    if(any(datlistscale_per_method %in% c(2,4)))stop("Generalized size compositions of unit of bin in either lbs or inches is  not supported")
    
    Nfrq<-sum(datlist$Nobs_per_method) ; frqlist<-setterFrqlist("Nfrq",Nfrq)
    Lbins<-datlist$size_freq_bins_list[[which(datlist$scale_per_method==3)[1]]]  ;frqlist<-setterFrqlist("Lbins",Lbins)
    NLbin<-length(Lbins);frqlist<-setterFrqlist("NLbin",NLbin)
    Lbin1st<-Lbins[1];frqlist<-setterFrqlist("Lbin1st",Lbin1st)
    Lbinwidth<-Lbins[2]-Lbins[1];frqlist<-setterFrqlist("Lbinwidth",Lbinwidth)
    LbinFactor<-1;frqlist<-setterFrqlist("LbinFactor",1)
    ##################################
    if(any(datlistscale_per_method==1)){
      Wbins<-datlist$size_freq_bins_list[[which(datlist$scale_per_method==1)[1]]]  ;frqlist<-setterFrqlist("Wbins",Wbins)
      NWbin<-length(Wbins);frqlist<-setterFrqlist("NWbin",NWbin)
      Wbin1st<-Wbins[1];frqlist<-setterFrqlist("Wbin1st",Wbin1st)
      Wbinwidth<-Wbins[2]-Wbins[1];frqlist<-setterFrqlist("Wbinwidth",Wbinwidth)
      WbinFactor<-1;frqlist<-setterFrqlist("WbinFactor",1)
    }else{
      Wbins<-0  ;frqlist<-setterFrqlist("Wbins",Wbins)
      NWbin<-0;frqlist<-setterFrqlist("NWbin",NWbin)
       Wbin1st<-0;frqlist<-setterFrqlist("Wbin1st",Wbin1st)
      Wbinwidth<-1;frqlist<-setterFrqlist("Wbinwidth",Wbinwidth)
      WbinFactor<-1;frqlist<-setterFrqlist("WbinFactor",1)
    }
  }
  age_nage<-0  ; frqlist<-setterFrqlist("age_nage",age_nage)   
  age_age1<--1 ; frqlist<-setterFrqlist("age_age1",age_age1) 
  

  FishDataStruct<-vector(mode="numeric",length=11)
  FishDataStruct[1]<-Nfrq
  FishDataStruct[2]<-NLbin
  FishDataStruct[3]<-Lbin1st
  FishDataStruct[4]<-Lbinwidth
  FishDataStruct[5]<-LbinFactor
  FishDataStruct[6]<-NWbin
  FishDataStruct[7]<-Wbin1st
  FishDataStruct[8]<-Wbinwidth
  FishDataStruct[9]<-WbinFactor
  FishDataStruct[10]<-age_nage
  FishDataStruct[11]<-age_age1
  

#
  if(verbose)cat("Starting to set the catch/effort/sample data\n")

  frqHeader<-list()
  frqCE<-list()
  frqData<-list()
  k<-0
  frqFlt<-sapply(datlist$sizefreq_data_list,function(x){unique(x$FltSvy)})
  for(j in 1:datlist$Nfleet){
    if(j %in% frqFlt ){
      if(length(frqFlt==j)==1){
        if(datlist$scale_per_method[which(frwFlt==j)]==3){ # Length composition data
          Lsizefreq<-datlist$sizefreq_data_list[[which(frqFlt==j)]]
          Wsizefreq<-NULL
        }else if(datlist$scale_per_method[which(frwFlt==j)]==4){ # Weight composition data
          Lsizefreq<-NULL
          Wsizefreq<-datlist$sizefreq_data_list[[which(frqFlt==j)]]
        }
      }else if(length(frqFlt==j)==2 ){
        for(jj in 1:2){
          if(datlist$scale_per_method[which(frwFlt==j)][jj]==3){
             Lsizefreq<-datlist$sizefreq_data_list[[which(frqFlt==j)[jj]]]
          }else if(datlist$scale_per_method[which(frwFlt==j)][jj]==4){
            Wsizefreq<-datlist$sizefreq_data_list[[which(frqFlt==j)[jj]]]
          }else{
            stop("L268")
          }
        }
      }
    }
    for(i in 1:datlist$N_catch){
      k<-k+1
      year<-datlist$catch[i,"year"]
      seas<-datlist$catch[i,"seas"]
      month<-(seas-1)*3+2
      week<-1
      fish<-j
      frqHeader[[k]]<-c(year,month,week,fish) 
      catch<-datlist$catch[i,j]
      if( j %in%  unique(datlist$CPUE[,"index"]) & 
        nrow(datlist$CPUE[datlist$CPUE$year==year & 
        datlist$CPUE$seas==seas & datlist$CPUE$index==j,])>0){
        effort<- catch/datlist$CPUE[datlist$CPUE$year==year & 
        														datlist$CPUE$seas==seas & datlist$CPUE$index==j,"obs"]
        pen<- 0.5/datlist$CPUE[datlist$CPUE$year==year & 
        												datlist$CPUE$seas==seas & 
        												datlist$CPUE$index==j,"se"]^2
      }else{
        effort<- -1
        pen<- 0.05
      }
      frqCE[[k]]<-c(catch,effort,pen)
      


      Lfrq<-if(sum(Lsizefreq$Yr==year & Lsizefreq$Seas==seas)>0){
        Lsizefreq[Lsizefreq$Yr==year & Lsizefreq$Seas==seas,8:ncol(Lsizefreq)]
      }else{
        -1
      }

      Wfrq<-if(sum(Wsizefreq$Yr==year & Wsizefreq$Seas==seas)>0){
        Wsizefreq[Wsizefreq$Yr==year & Wsizefreq$Seas==seas,8:ncol(Wsizefreq)]
      }else{
        -1
      }      

      frqData[[k]]<-list(Lfrq=Lfrq,Wfrq=Wfrq)
    } 
  }
  for(i in which(datlist$CPUE$index %in% datlist$Nfleet+1:datlist$surveys)){
    k<-k+1
    year<-datlist$CPUE[i,"year"]
    month<-if(datlist$nseas==4){
      (datlist$CPUE[i,"seas"]-1)*3+2
    }else{
      2
    }
    week<-1
    fish<-datlist$CPUE[i,"index"]      
    frqHeader[[k]]<-c(year,month,week,fish) 
    catch<-10
    effort<- catch/datlist$CPUE[i,"obs"]
    pen<- 0.5/datlist$CPUE[i,"se"]^2
    frqCE[[k]]<-c(catch,effort,pen)
    frqData[[k]]<-list(Lfrq=-1,Wfrq=-1) 
    # Current code does not support survey data which has their own size composition data 
  }
  frqlist$frq<-list(frqHeader=frqHeader,frqCE=frqCE,frqData=frqData)
  cat("L328\n") #;browser()

  return(frqlist)
}